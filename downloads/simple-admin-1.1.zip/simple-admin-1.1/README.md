simple-admin
============
Scripts for simplified Ubuntu server administration and
maintenance.

Web Site: http://cederberg.github.com/simple-admin


Requirements
------------
* Ubuntu 10.04 LTS (or later)
* ...and some command-line tools (auto-installed)


Installation
------------
The install script will install required command-line tools and
Perl modules.

1. Run install script: `./install.sh`
2. Copy & modify config files from `etc`.

